import json

from kvf.services.session_service import SessionService

from kvf.models.application import Application
from kvf.repositories.script_repository import ScriptRepository
from kvf.services.prompt_service import PromptService
from kvf.steps.base_step import BaseStep
from kvf.utils.file_utils import file_exists


class GenerateStoryboardPromptStep(BaseStep):

    def execute(
        self,
        application: Application,
    ) -> None:

        workspace = application.project.workspace
        source_dir = application.project.source_dir

        prompt_path = (
            source_dir / "storyboard_prompt.md"
        )

        if file_exists(prompt_path):
            print("Storyboard prompt already exists. [SKIP]")
            return

        script_path = (
            source_dir / "script.json"
        )

        script = ScriptRepository().load(
            script_path
        )

        metadata = SessionService._read_metadata(workspace)
        profile = metadata.get("edition_profile", {})
        context = {
            "topic": script.topic,
            "output_language": metadata.get("output_language", "English"),
            "search_query_rule": profile.get("search_query_rule", "Write concise English visual search queries."),
            "script": json.dumps(
                script.model_dump(),
                indent=2,
                ensure_ascii=False,
            ),
        }

        prompt = PromptService().render(
            "prompts/storyboard.md",
            context,
        )

        prompt_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        prompt_path.write_text(
            prompt,
            encoding="utf-8",
        )

        print(
            f"Storyboard prompt generated: {prompt_path} [DONE]"
        )